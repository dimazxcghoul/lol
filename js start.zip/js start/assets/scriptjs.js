// let num1 = 10
// let num2 = 20
// let num3 = 30
// let str = 'str1'

let array = [1, 42.2, 'str'];
console.log(array)


// IF

// if (num1 == 10 && num2 >0) {
//     console.log('if')
// }

// SWITCH-CASE

// switch (str) {
//     case 'str':
//         console.log('case-1');
//         break;
//     case 'str1':
//         console.log('case-2');
//         break;
//     default:
//         console.log('Default');

// }

// FOR

// for (let i = 0; i < array.length; i++) {
//     console.log(array[i])
// }

// WHILE

// let j = 0
// while(j<10) {
//     console.log(j)
//     j++
// }



function OnClick(){
    alert('lol')
}

function OnMouseOver(el) {
    console.log(1)
    el.innerHTML = 'Yey'
    el.style.cssText = 'border-radius: 2px; border: 2px solid black'
}


let txt = document.getElementById('description');

let lol = 0
let labels = document.getElementsByTagName('label')

document.getElementById('main-form').addEventListener('submit', checkForm)

function checkForm(event){
    event.preventDefault();
    el = document.getElementById('main-form')

    let name = el.name.value
    let pass = el.pass.value
    let repass = el.repass.value
    let state = el.state.value

    let fail = ''
    
    if(name == '') {
        fail = 'Введите имя!!';
        el.name.style.background = 'red';
    } 
    else if(name.length <=1){
        fail = 'Введите имя корректно!!';  
    }
    if(pass == '') {
        el.pass.style.background = 'red';
    }

    if(fail != ''){
        document.getElementById('error').innerHTML = fail
    }
    else {
        alert('Все верно!');
    }
    
}

function copy(txt){
    return navigator.clipboard.writeText(txt)
}


tel = document.getElementById('tel')
const originalText = tel.textContent;

tel.addEventListener('click', function() { 
    copy(tel.textContent); 
    tel.textContent = 'Успешно скопировано';
    tel.style.color = 'green'
    setTimeout(function(){
        tel.style.color = 'black'
        tel.textContent = originalText;
    }, 1000)
  });
