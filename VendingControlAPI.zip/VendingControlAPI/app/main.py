from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi_pagination import add_pagination
from fastapi.openapi.utils import get_openapi
from app.backend.database.database import *
from fastapi.middleware.cors import CORSMiddleware
from app.backend.models import *
from app.backend.api.router_auth import router as auth_router
from app.backend.api.router_roles import router as roles_router
from app.backend.api.router_user import router as user_router
from app.backend.api.router_machine_products import router as machine_products_router
from app.backend.api.router_payment_type import router as payment_type_router
from app.backend.api.router_product import router as product_router
from app.backend.api.router_sales import router as sales_router
from app.backend.api.router_status_machine import router as status_machine_router
from app.backend.api.router_vending_machines import router as vending_machine_router
from app.backend.api.router_maintenance import router as maintenance_router
from app.backend.api.router_news import router as news_router
from app.backend.api.router_type_services import router as type_services_router
from app.backend.api.router_collected import router as collected_router
from app.backend.api.router_operating_mode import router as operating_mode_router
from app.backend.api.router_service_priority import router as service_priority_router
from app.backend.api.router_time_zone import router as time_zone_router

main_app = FastAPI()


@asynccontextmanager
async def on_startup(app: FastAPI):
    '''
    Инициализация БД при запуске приложения
    :params: app: FastAPI
    :return: init_db()
    '''
    init_db()
    yield
    close_db()


app_v1 = FastAPI(
    title='Vending Control API v1',
    version='1.0.0',
    openapi_url='/openapi.json',
    docs_url='/docs',
    redoc_url='/redoc',
    lifespan=on_startup,
    swagger_ui_parameters={
        "persistAuthorization": True,
        "displayRequestDuration": True
    }
)

app_v1.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

main_app.mount('/api/v1', app_v1)

app_v1.include_router(auth_router, prefix='/auth', tags=['Authorization'])
app_v1.include_router(roles_router, tags=['Roles'])
app_v1.include_router(user_router, tags=['User'])
app_v1.include_router(machine_products_router, tags=['MachineProducts'])
app_v1.include_router(payment_type_router, tags=['PaymentType'])
app_v1.include_router(product_router, tags=['Product'])
app_v1.include_router(sales_router, tags=['Sales'])
app_v1.include_router(status_machine_router, tags=['StatusMachine'])
app_v1.include_router(vending_machine_router, tags=['VendingMachine'])
app_v1.include_router(maintenance_router, tags=['Maintenance'])
app_v1.include_router(news_router, tags=['News'])
app_v1.include_router(type_services_router, tags=['TypeServices'])
app_v1.include_router(collected_router, tags=['Collected'])
app_v1.include_router(operating_mode_router, tags=['OperatingMode'])
app_v1.include_router(service_priority_router, tags=['ServicePriority'])
app_v1.include_router(time_zone_router, tags=['TimeZone'])
add_pagination(app_v1)
