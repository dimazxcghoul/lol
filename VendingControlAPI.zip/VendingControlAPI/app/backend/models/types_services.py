from sqlmodel import SQLModel, Field


class TypesServices(SQLModel, table=True):
    id_type: int = Field(primary_key=True, default=None)
    type: str
