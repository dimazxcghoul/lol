from typing import List
from sqlmodel import SQLModel, Field


class PaymentType(SQLModel, table=True):
    payment_id: int = Field(default=None, primary_key=True)
    type: str = Field(max_length=50)