from sqlmodel import SQLModel, Field


class ServicePriority(SQLModel, table=True):
    id_priority: int = Field(primary_key=True, default=None)
    priority: str