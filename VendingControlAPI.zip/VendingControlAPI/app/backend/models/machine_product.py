from typing import Optional
from sqlmodel import SQLModel, Field


class MachineProducts(SQLModel, table=True):
    machine_product_id: int = Field(primary_key=True, default=None)
    machine_id: int = Field(foreign_key="vendingmachines.machine_id")
    product_id: int = Field(foreign_key="product.product_id")
