from typing import Optional, List
from sqlmodel import SQLModel, Field


class Users(SQLModel, table=True):
    user_id: int = Field(primary_key=True, default=None)
    full_name: str = Field(max_length=100)
    email: str = Field(max_length=50)
    phone: Optional[str] = Field(max_length=20, default=None)
    password: str = Field(max_length=50)
    hashed_password: str = Field(max_length=100)
    role_id: int = Field(foreign_key='roles.role_id')