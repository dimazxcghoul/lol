from sqlmodel import SQLModel, Field


class TimeZone(SQLModel, table=True):
    id_zone: int = Field(primary_key=True, default=None)
    time_zone: str