from sqlmodel import SQLModel, Field


class Roles(SQLModel, table=True):
    role_id: int = Field(primary_key=True, default=None)
    role: str = Field(max_length=50, default=None)