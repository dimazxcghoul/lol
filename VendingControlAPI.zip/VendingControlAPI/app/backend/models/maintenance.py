from datetime import date
from typing import Optional
from sqlmodel import SQLModel, Field


class Maintenance(SQLModel, table=True):
    maintenance_id: Optional[int] = Field(default=None, primary_key=True)
    machine_id: int = Field(foreign_key="vendingmachines.machine_id")
    maintenance_date: date = Field(default_factory=date.today)
    work_description: str = Field()
    problems_found: Optional[str] = Field(default=None)
    performer_id: int = Field(foreign_key="users.user_id")
    type_services: int = Field(foreign_key='typesservices.id_type')
    status: str
