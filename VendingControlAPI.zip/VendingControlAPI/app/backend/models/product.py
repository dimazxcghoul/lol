from typing import Optional, List
from sqlmodel import SQLModel, Field


class Product(SQLModel, table=True):
    product_id: Optional[int] = Field(default=None, primary_key=True)
    product_name: str = Field(max_length=100)
    description: Optional[str] = None
    price: float = Field()
    quantity: int = Field()
    minimum_stock: int = Field(default=5)
    sales_tendency: Optional[float] = Field(default=0.0)
