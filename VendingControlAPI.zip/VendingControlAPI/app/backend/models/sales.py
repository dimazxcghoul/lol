from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel, Field


class Sales(SQLModel, table=True):
    sale_id: int = Field(primary_key=True, default=None)
    machine_id: int = Field(foreign_key="vendingmachines.machine_id")
    product_id: int = Field(foreign_key="product.product_id")
    quantity: int = Field()
    sale_amount: float = Field()
    sale_datetime: datetime = Field(default_factory=datetime.utcnow)
    payment_type: int = Field(foreign_key="paymenttype.payment_id")