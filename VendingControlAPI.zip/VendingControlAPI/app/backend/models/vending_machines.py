from datetime import date
from typing import Optional
from sqlmodel import SQLModel, Field


class VendingMachines(SQLModel, table=True):
    machine_id: Optional[int] = Field(default=None, primary_key=True)
    model: str = Field(max_length=50)
    payment_type: int = Field(foreign_key="paymenttype.payment_id")
    total_revenue: float = Field(default=0.0)
    serial_number: int = Field()
    inventory_number: int = Field()
    producer: Optional[str] = Field(max_length=50, default=None)
    production_date: date = Field()
    commission_date: date = Field()
    last_verification_date: Optional[date] = Field(default=None)
    verification_interval_months: Optional[int] = Field(default=None)
    resource_hours: int = Field()
    next_verification_date: Optional[date] = Field(default=None)
    status_id: int = Field(foreign_key="statusmachine.status_id")
    production_country: str = Field(max_length=50)
    inventory_date: date = Field()
    verification_employee_id: int = Field(foreign_key="users.user_id")
    change: int
    name_machine: str
    address: str
    coordinates: str
    opening_hours: str
    notes: str
    time_zone: int = Field(foreign_key='timezone.id_zone')
    service_priority: int = Field('servicepriority.id_priority')
    operating_mode: int = Field('operatingmode.id_mode')