from sqlmodel import SQLModel, Field


class StatusMachine(SQLModel, table=True):
    status_id: int = Field(primary_key=True, default=None)
    status: str = Field(max_length=50)