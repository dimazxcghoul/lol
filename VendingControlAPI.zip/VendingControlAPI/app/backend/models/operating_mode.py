from sqlmodel import SQLModel, Field


class OperatingMode(SQLModel, table=True):
    id_mode: int = Field(primary_key=True, default=None)
    mode: str