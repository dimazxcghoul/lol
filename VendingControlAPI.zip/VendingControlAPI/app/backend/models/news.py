from datetime import datetime

from sqlmodel import SQLModel, Field


class News(SQLModel, table=True):
    news_id: int = Field(primary_key=True, default=None)
    news: str = Field(max_length=255)
    date: datetime = Field(default_factory=datetime.utcnow)