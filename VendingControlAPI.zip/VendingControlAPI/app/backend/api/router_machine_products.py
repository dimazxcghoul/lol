from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.machine_products_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import MachineProductsCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/machine_products/{machine_products_id}',
            summary="Получить продукт в машине по ID",
            description='Поиск продукта в машине по ID')
def router_get_machine_products_by_id(
        machine_products_id: int,
        session: Session = Depends(get_session)
):
    return get_machine_products_by_id(machine_products_id, session)


@router.post('/machine_products',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый продукт в машине",
             description='Добавление продукта в машине')
def router_add_machine_products(
        data: MachineProductsCreate,
        session: Session = Depends(get_session)
):
    return add_machine_products(data, session)


@router.delete('/machine_products/{machine_products_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить продукт в машине",
               description='Удаление продукта в машине')
def router_delete_machine_products(
        machine_products_id: int,
        session: Session = Depends(get_session)
):
    return delete_machine_products(machine_products_id, session)


@router.put('/machine_products/{machine_products_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные продукта в машине",
            description='Изменение продукта в машине')
def router_update_machine_products(
        machine_products_id: int,
        data: MachineProducts,
        session: Session = Depends(get_session)
):
    return update_machine_products(machine_products_id, data, session)


@router.get('/machine_products',
            summary="Получить список продуктов в машине",
            description='Вывод информации о продуктах в машине',
            response_model=Page[MachineProducts])
def router_show_machine_products(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_machine_products(session, page, size)
