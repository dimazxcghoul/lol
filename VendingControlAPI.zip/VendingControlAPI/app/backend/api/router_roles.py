from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.roles_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import RolesCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/role/{role_id}',
            summary="Получить роль по ID",
            description='Поиск роль по ID')
def router_get_role_by_id(
        role_id: int,
        session: Session = Depends(get_session)
):
    return get_role_by_id(role_id, session)


@router.post('/role',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новую роль",
             description='Добавление роли')
def router_add_role(
        data: RolesCreate,
        session: Session = Depends(get_session)
):
    return add_role(data, session)


@router.delete('/role/{role_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить роль",
               description='Удаление роль')
def router_delete_role(
        role_id: int,
        session: Session = Depends(get_session)
):
    return delete_role(role_id, session)


@router.put('/role/{role_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные роли",
            description='Изменение роли')
def router_update_role(
        role_id: int,
        data: Roles,
        session: Session = Depends(get_session)
):
    return update_role(role_id, data, session)


@router.get('/role',
            summary="Получить список ролей",
            description='Вывод информации о ролях',
            response_model=Page[Roles])
def router_show_role(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_roles(session, page, size)
