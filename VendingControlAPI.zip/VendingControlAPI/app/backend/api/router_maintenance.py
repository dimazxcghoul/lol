from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.maintenance_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import MaintenanceCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/maintenance/{maintenance_id}',
            summary="Получить обслуживание по ID",
            description='Поиск обслуживания по ID')
def router_get_maintenance_by_id(
        product_id: int,
        session: Session = Depends(get_session)
):
    return get_maintenance_by_id(product_id, session)


@router.post('/maintenance',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новое обслуживание",
             description='Добавление обслуживание')
def router_add_maintenance(
        data: MaintenanceCreate,
        session: Session = Depends(get_session)
):
    return add_maintenance(data, session)


@router.delete('/maintenance/{maintenance_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить обслуживание",
               description='Удаление обслуживания')
def router_delete_maintenance(
        maintenance_id: int,
        session: Session = Depends(get_session)
):
    return delete_maintenance(maintenance_id, session)


@router.put('/maintenance/{maintenance_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные обслуживания",
            description='Изменение обслуживания')
def router_update_maintenance(
        maintenance_id: int,
        data: Maintenance,
        session: Session = Depends(get_session)
):
    return update_maintenance(maintenance_id, data, session)


@router.get('/maintenance',
            summary="Получить список обслуживания",
            description='Вывод информации о обслуживаниях',
            response_model=Page[Maintenance])
def router_show_maintenance(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_maintenance(session, page, size)