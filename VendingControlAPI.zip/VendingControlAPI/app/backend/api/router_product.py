from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.product_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import ProductCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/product/{product_id}',
            summary="Получить продукт по ID",
            description='Поиск продукта по ID')
def router_get_product_by_id(
        product_id: int,
        session: Session = Depends(get_session)
):
    return get_product_by_id(product_id, session)


@router.post('/product',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый продукт",
             description='Добавление продукта')
def router_add_product(
        data: ProductCreate,
        session: Session = Depends(get_session)
):
    return add_product(data, session)


@router.delete('/product/{product_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить продукт",
               description='Удаление продукта')
def router_delete_product(
        product_id: int,
        session: Session = Depends(get_session)
):
    return delete_product(product_id, session)


@router.put('/product/{product_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные продукта",
            description='Изменение продукта')
def router_update_product(
        product_id: int,
        data: Product,
        session: Session = Depends(get_session)
):
    return update_product(product_id, data, session)


@router.get('/product',
            summary="Получить список продуктов",
            description='Вывод информации о продуктах',
            response_model=Page[Product])
def router_show_products(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_products(session, page, size)