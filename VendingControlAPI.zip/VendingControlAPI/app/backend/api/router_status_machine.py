from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.status_machine_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import StatusMachineCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/status_machine/{status_machine_id}',
            summary="Получить статус машины по ID",
            description='Поиск статуса машины по ID')
def router_get_status_machine_by_id(
        status_machine_id: int,
        session: Session = Depends(get_session)
):
    return get_status_machine_by_id(status_machine_id, session)


@router.post('/status_machine',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый статус машины",
             description='Добавление статуса машины')
def router_add_status_machine(
        data: StatusMachineCreate,
        session: Session = Depends(get_session)
):
    return add_status_machine(data, session)


@router.delete('/status_machine/{status_machine_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить статус машины",
               description='Удаление статуса машины')
def router_delete_status_machine(
        status_machine_id: int,
        session: Session = Depends(get_session)
):
    return delete_status_machine(status_machine_id, session)


@router.put('/status_machine/{status_machine_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные статуса машины",
            description='Изменение статуса машины')
def router_update_status_machine(
        status_machine_id: int,
        data: StatusMachine,
        session: Session = Depends(get_session)
):
    return update_status_machine(status_machine_id, data, session)


@router.get('/status_machine',
            summary="Получить список статусов машины",
            description='Вывод информации о статусах машины',
            response_model=Page[StatusMachine])
def router_show_status_machines(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_status_machines(session, page, size)