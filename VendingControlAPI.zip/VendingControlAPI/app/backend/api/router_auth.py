import os

from dotenv import load_dotenv
from fastapi import APIRouter, Depends
from sqlmodel import Session
from app.backend.database.session import get_session
from app.backend.schemas.schemas_requests import UserLogin, Token, TokenRefresh
from app.backend.controllers.auth_controller import login_user
from app.backend.schemas.schemas_response import TokenResponse

router = APIRouter()

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = os.getenv("ALGORITHM")


@router.post("/login", response_model=Token, summary='Авторизация')
def login(login_data: UserLogin, session: Session = Depends(get_session)):
    return login_user(login_data, session)
