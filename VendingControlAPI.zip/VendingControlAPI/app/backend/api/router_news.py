from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.news_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import NewsCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/news/{news_id}',
            summary="Получить новость по ID",
            description='Поиск новости по ID')
def router_get_news_by_id(
        product_id: int,
        session: Session = Depends(get_session)
):
    return get_news_by_id(product_id, session)


@router.post('/news',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новую новость",
             description='Добавление новости')
def router_add_news(
        data: NewsCreate,
        session: Session = Depends(get_session)
):
    return add_news(data, session)


@router.delete('/news/{news_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить новость",
               description='Удаление новости')
def router_delete_news(
        product_id: int,
        session: Session = Depends(get_session)
):
    return delete_news(product_id, session)


@router.put('/news/{news_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные новости",
            description='Изменение новости')
def router_update_news(
        product_id: int,
        data: News,
        session: Session = Depends(get_session)
):
    return update_news(product_id, data, session)


@router.get('/news',
            summary="Получить список новостей",
            description='Вывод информации о новостях',
            response_model=Page[News])
def router_show_news(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_news(session, page, size)