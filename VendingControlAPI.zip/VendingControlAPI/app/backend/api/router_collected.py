from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.collected_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import CollectedCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/collected/{collected_id}',
            summary="Получить инкассацию по ID",
            description='Поиск инкассации по ID')
def router_get_collected_by_id(
        collected_id: int,
        session: Session = Depends(get_session)
):
    return get_collected_by_id(collected_id, session)


@router.post('/collected',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый инкассацию",
             description='Добавление инкассации')
def router_add_collected(
        data: CollectedCreate,
        session: Session = Depends(get_session)
):
    return add_collected(data, session)


@router.delete('/collected/{collected_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить инкассацию",
               description='Удаление инкассации')
def router_delete_collected(
        collected_id: int,
        session: Session = Depends(get_session)
):
    return delete_collected(collected_id, session)


@router.put('/collected/{collected_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные инкассации",
            description='Изменение инкассации')
def router_update_collected(
        collected_id: int,
        data: Collected,
        session: Session = Depends(get_session)
):
    return update_collected(collected_id, data, session)


@router.get('/collected',
            summary="Получить список инкассаций",
            description='Вывод информации о инкассациях',
            response_model=Page[Collected])
def router_show_collected(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_collected(session, page, size)