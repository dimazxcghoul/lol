from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.types_services_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import TypeServicesCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/types_services/{types_services_id}',
            summary="Получить тип сервиса по ID",
            description='Поиск типа сервиса по ID')
def router_get_types_services_by_id(
        types_services_id: int,
        session: Session = Depends(get_session)
):
    return get_types_services_by_id(types_services_id, session)


@router.post('/types_services',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый тип сервиса",
             description='Добавление типа сервиса')
def router_add_types_services(
        data: TypeServicesCreate,
        session: Session = Depends(get_session)
):
    return add_types_services(data, session)


@router.delete('/types_services/{types_services_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить тип сервиса",
               description='Удаление типа сервиса')
def router_delete_types_services(
        types_services_id: int,
        session: Session = Depends(get_session)
):
    return delete_types_services(types_services_id, session)


@router.put('/types_services/{types_services_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные типа сервиса",
            description='Изменение типа сервиса')
def router_update_types_services(
        types_services_id: int,
        data: TypesServices,
        session: Session = Depends(get_session)
):
    return update_types_services(types_services_id, data, session)


@router.get('/types_services',
            summary="Получить список типов сервиса",
            description='Вывод информации о типах сервиса',
            response_model=Page[TypesServices])
def router_show_types_services(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_types_services(session, page, size)