from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.service_priority_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import ServicePriorityCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/service_priority/{service_priority_id}',
            summary="Получить приоритет обслуживания по ID",
            description='Поиск приоритета обслуживания по ID')
def router_get_service_priority_by_id(
        service_priority_id: int,
        session: Session = Depends(get_session)
):
    return get_service_priority_by_id(service_priority_id, session)


@router.post('/service_priority',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый приоритет обслуживания",
             description='Добавление приоритета обслуживания')
def router_add_service_priority(
        data: ServicePriorityCreate,
        session: Session = Depends(get_session)
):
    return add_service_priority(data, session)


@router.delete('/service_priority/{service_priority_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить приоритет обслуживания",
               description='Удаление приоритета обслуживания')
def router_delete_service_priority(
        service_priority_id: int,
        session: Session = Depends(get_session)
):
    return delete_service_priority(service_priority_id, session)


@router.put('/service_priority/{service_priority_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные приоритета обслуживания",
            description='Изменение приоритета обслуживания')
def router_update_service_priority(
        service_priority_id: int,
        data: ServicePriority,
        session: Session = Depends(get_session)
):
    return update_service_priority(service_priority_id, data, session)


@router.get('/service_priority',
            summary="Получить список приоритетов обслуживания",
            description='Вывод информации о приоритетах обслуживания',
            response_model=Page[ServicePriority])
def router_show_service_priority(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_service_priority(session, page, size)