from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.sales_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import SalesCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/sales/{sales_id}',
            summary="Получить продажу по ID",
            description='Поиск продажи по ID')
def router_get_sales_by_id(
        sales_id: int,
        session: Session = Depends(get_session)
):
    return get_sales_by_id(sales_id, session)


@router.post('/sales',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новую продажу",
             description='Добавление продажи')
def router_add_sales(
        data: SalesCreate,
        session: Session = Depends(get_session)
):
    return add_sales(data, session)


@router.delete('/sales/{role_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить продажу",
               description='Удаление продажи')
def router_delete_sales(
        sales_id: int,
        session: Session = Depends(get_session)
):
    return delete_sales(sales_id, session)


@router.put('/sales/{sales_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные продажи",
            description='Изменение продажи')
def router_update_sales(
        sales_id: int,
        data: Sales,
        session: Session = Depends(get_session)
):
    return update_sales(sales_id, data, session)


@router.get('/sales',
            summary="Получить список продаж",
            description='Вывод информации о продажах',
            response_model=Page[Sales])
def router_show_sales(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_sales(session, page, size)