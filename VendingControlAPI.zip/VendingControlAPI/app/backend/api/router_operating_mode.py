from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.operating_mode_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import OperatingModeCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/operating_mode/{operating_mode_id}',
            summary="Получить режим работы по ID",
            description='Поиск новости по ID')
def router_get_operating_mode_by_id(
        operating_mode_id: int,
        session: Session = Depends(get_session)
):
    return get_operating_mode_by_id(operating_mode_id, session)


@router.post('/operating_mode',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новый режим работы",
             description='Добавление режима работы')
def router_add_operating_mode(
        data: OperatingModeCreate,
        session: Session = Depends(get_session)
):
    return add_operating_mode(data, session)


@router.delete('/operating_mode/{operating_mode_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить режим работы",
               description='Удаление режима работы')
def router_delete_operating_mode(
        operating_mode_id: int,
        session: Session = Depends(get_session)
):
    return delete_operating_mode(operating_mode_id, session)


@router.put('/operating_mode/{operating_mode_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные режима работы",
            description='Изменение режима работы')
def router_update_operating_mode(
        operating_mode_id: int,
        data: OperatingMode,
        session: Session = Depends(get_session)
):
    return update_operating_mode(operating_mode_id, data, session)


@router.get('/operating_mode',
            summary="Получить список режимов работы",
            description='Вывод информации о режимах работы',
            response_model=Page[OperatingMode])
def router_show_operating_mode(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_operating_mode(session, page, size)