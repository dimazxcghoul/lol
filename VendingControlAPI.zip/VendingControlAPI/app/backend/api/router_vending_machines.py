from fastapi import Depends, status, APIRouter
from fastapi_pagination import Page
from sqlmodel import Session
from app.backend.controllers.vending_machines_controller import *
from app.backend.database.session import get_session
from app.backend.models.users import Users
from app.backend.schemas.schemas_requests import VendingMachinesCreate
from app.backend.security.auth_deps import require_roles, get_current_user

router = APIRouter()


@router.get('/vending_machines/{vending_machines_id}',
            summary="Получить машину по ID",
            description='Поиск машины по ID')
def router_get_vending_machine_by_id(
        vending_machines_id: int,
        session: Session = Depends(get_session)
):
    return get_vending_machines_by_id(vending_machines_id, session)


@router.post('/vending_machines',
             status_code=status.HTTP_201_CREATED,
             summary="Добавить новую машину",
             description='Добавление машины')
def router_add_vending_machine(
        data: VendingMachinesCreate,
        session: Session = Depends(get_session)
):
    return add_vending_machines(data, session)


@router.delete('/vending_machines/{vending_machines_id}',
               status_code=status.HTTP_204_NO_CONTENT,
               summary="Удалить машину",
               description='Удаление машины')
def router_delete_vending_machine(
        vending_machines_id: int,
        session: Session = Depends(get_session)
):
    return delete_vending_machines(vending_machines_id, session)


@router.put('/vending_machines/{vending_machines_id}',
            status_code=status.HTTP_200_OK,
            summary="Обновить данные машины",
            description='Изменение машины')
def router_update_vending_machine(
        vending_machines_id: int,
        data: VendingMachines,
        session: Session = Depends(get_session)
):
    return update_vending_machines(vending_machines_id, data, session)


@router.get('/vending_machines',
            summary="Получить список машин",
            description='Вывод информации о машинах',
            response_model=Page[VendingMachines])
def router_show_vending_machines(
        session: Session = Depends(get_session),
        page: int = 1,
        size: int = 10
):
    return show_vending_machines(session, page, size)