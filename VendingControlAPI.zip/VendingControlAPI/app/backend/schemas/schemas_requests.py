from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel


class MachineProductsCreate(BaseModel):
    machine_id: int
    product_id: int


class MaintenanceCreate(BaseModel):
    machine_id: int
    maintenance_date: date
    work_description: str
    problems_found: Optional[str]
    performer_id: int


class PaymentTypeCreate(BaseModel):
    type: str


class ProductCreate(BaseModel):
    product_name: str
    description: Optional[str]
    price: float
    quantity: int
    minimum_stock: int
    sales_tendency: Optional[float]


class RolesCreate(BaseModel):
    role: str


class SalesCreate(BaseModel):
    machine_id: int
    product_id: int
    quantity: int
    sale_amount: float
    sale_datetime: datetime
    payment_type: int


class StatusMachineCreate(BaseModel):
    status: str


class UsersCreate(BaseModel):
    full_name: str
    email: str
    phone: Optional[str]
    password: str
    role_id: int


class UserLogin(BaseModel):
    email: str
    password: str


class VendingMachinesCreate(BaseModel):
    model: str
    payment_type: int
    total_revenue: float
    serial_number: int
    inventory_number: int
    producer: Optional[str]
    production_date: date
    commission_date: date
    last_verification_date: Optional[date]
    verification_interval_months: Optional[int]
    resource_hours: int
    next_verification_date: Optional[date]
    status_id: int
    production_country: str
    inventory_date: date
    verification_employee_id: int
    change: int
    name_machine: str
    address: str
    coordinates: str
    opening_hours: str
    notes: str
    time_zone: int
    service_priority: int
    operating_mode: int


class OperatingModeCreate(BaseModel):
    mode: str


class ServicePriorityCreate(BaseModel):
    mode: str


class TimeZoneCreate(BaseModel):
    time_zone: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    refresh_token: Optional[str] = None


class TokenRefresh(BaseModel):
    refresh_token: str


class TokenData(BaseModel):
    username: Optional[str] = None


class NewsCreate(BaseModel):
    news: str
    date: datetime


class TypeServicesCreate(BaseModel):
    type: str


class CollectedCreate(BaseModel):
    machine_id: int
    total_sum: int
    date_collected: date
