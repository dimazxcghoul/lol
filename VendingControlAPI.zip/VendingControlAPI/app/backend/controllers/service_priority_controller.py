from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import ServicePriority


def get_service_priority_by_id(id, session) -> ServicePriority:
    '''
    Поиск приоритета обслуживания по ID
    :param id:
    :param session:
    :return: ServicePriority
    '''
    try:
        result = session.get(ServicePriority, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_service_priority(data, session) -> Optional[ServicePriority]:
    '''
    Добавление приоритета обслуживания
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = ServicePriority(
            priority=data.priority
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_service_priority(id, session) -> str:
    '''
    Удаление приоритета обслуживания
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(ServicePriority, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_service_priority(id, data, session) -> ServicePriority:
    '''
    Изменение приоритета обслуживания
    :param data:
    :param session:
    :return: ServicePriority
    '''
    try:
        result = session.get(ServicePriority, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_service_priority(session: Session, page: int = 1, size: int = 10) -> Page[ServicePriority]:
    '''
    Вывод информации о приоритетах обслуживания
    :param session:
    :param page
    :param size
    :return: List[ServicePriority]
    '''
    try:
        sql = select(ServicePriority)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")