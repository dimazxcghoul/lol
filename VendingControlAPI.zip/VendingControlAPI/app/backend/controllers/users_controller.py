from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import Users
from app.backend.security.auth_utils import get_password_hash


def get_user_by_id(id, session) -> Users:
    '''
    Поиск пользователя по ID
    :param id:
    :param session:
    :return: Users
    '''
    try:
        result = session.get(Users, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_user(data, session) -> Optional[Users]:
    '''
    Добавление пользователя
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = Users(
            full_name=data.full_name,
            email=data.email,
            phone=data.phone,
            password=data.password,
            hashed_password=get_password_hash(data.password),
            role_id=data.role_id
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_user(id, session) -> str:
    '''
    Удаление пользователя
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(Users, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_user(id, data, session) -> Users:
    '''
    Изменение пользователя
    :param data:
    :param session:
    :return: Users
    '''
    try:
        result = session.get(Users, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_users(session: Session, page: int = 1, size: int = 10) -> Page[Users]:
    '''
    Вывод информации о пользователях
    :param session:
    :param page
    :param size
    :return: List[Users]
    '''
    try:
        sql = select(Users)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")