from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import Sales


def get_sales_by_id(id, session) -> Sales:
    '''
    Поиск продаж по ID
    :param id:
    :param session:
    :return: Sales
    '''
    try:
        result = session.get(Sales, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_sales(data, session) -> Optional[Sales]:
    '''
    Добавление продажи
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = Sales(
            machine_id=data.machine_id,
            product_id=data.product_id,
            quantity=data.quantity,
            sale_amount=data.sale_amount,
            sale_datetime=data.sale_datetime,
            payment_type=data.payment_type
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_sales(id, session) -> str:
    '''
    Удаление продажи
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(Sales, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_sales(id, data, session) -> Sales:
    '''
    Изменение продажи
    :param data:
    :param session:
    :return: Sales
    '''
    try:
        result = session.get(Sales, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_sales(session: Session, page: int = 1, size: int = 10) -> Page[Sales]:
    '''
    Вывод информации о продажах
    :param session:
    :param page
    :param size
    :return: List[Sales]
    '''
    try:
        sql = select(Sales)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")