from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import TimeZone


def get_time_zone_by_id(id, session) -> TimeZone:
    '''
    Поиск часового пояса по ID
    :param id:
    :param session:
    :return: TimeZone
    '''
    try:
        result = session.get(TimeZone, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_time_zone(data, session) -> Optional[TimeZone]:
    '''
    Добавление часового пояса
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = TimeZone(
            time_zone=data.time_zone
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_time_zone(id, session) -> str:
    '''
    Удаление часового пояса
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(TimeZone, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_time_zone(id, data, session) -> TimeZone:
    '''
    Изменение часового пояса
    :param data:
    :param session:
    :return: TimeZone
    '''
    try:
        result = session.get(TimeZone, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_time_zone(session: Session, page: int = 1, size: int = 10) -> Page[TimeZone]:
    '''
    Вывод информации о часовых поясах
    :param session:
    :param page
    :param size
    :return: List[TimeZone]
    '''
    try:
        sql = select(TimeZone)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")