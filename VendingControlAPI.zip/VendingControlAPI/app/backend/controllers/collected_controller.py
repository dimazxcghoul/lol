from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models.collected import Collected


def get_collected_by_id(id, session) -> Collected:
    '''
    Поиск инкассации по ID
    :param id:
    :param session:
    :return: Collected
    '''
    try:
        result = session.get(Collected, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_collected(data, session) -> Optional[Collected]:
    '''
    Добавление инкассации
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = Collected(
            machine_id=data.machine_id,
            total_sum=data.total_sum,
            date_collected=data.date_collected
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_collected(id, session) -> str:
    '''
    Удаление инкассации
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(Collected, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_collected(id, data, session) -> Collected:
    '''
    Изменение инкассации
    :param data:
    :param session:
    :return: Collected
    '''
    try:
        result = session.get(Collected, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_collected(session: Session, page: int = 1, size: int = 10) -> Page[Collected]:
    '''
    Вывод информации о инкассациях
    :param session:
    :param page
    :param size
    :return: List[Collected]
    '''
    try:
        sql = select(Collected)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")