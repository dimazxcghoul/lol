from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import VendingMachines


def get_vending_machines_by_id(id, session) -> VendingMachines:
    '''
    Поиск машины по ID
    :param id:
    :param session:
    :return: VendingMachines
    '''
    try:
        result = session.get(VendingMachines, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_vending_machines(data, session) -> Optional[VendingMachines]:
    '''
    Добавление машины
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = VendingMachines(
            model=data.model,
            payment_type=data.payment_type,
            total_revenue=data.total_revenue,
            serial_number=data.serial_number,
            inventory_number=data.inventory_number,
            producer=data.producer,
            production_date=data.production_date,
            commission_date=data.commission_date,
            last_verification_date=data.last_verification_date,
            verification_interval_months=data.verification_interval_months,
            resource_hours=data.resource_hours,
            next_verification_date=data.next_verification_date,
            status_id=data.status_id,
            production_country=data.production_country,
            inventory_date=data.inventory_date,
            verification_employee_id=data.verification_employee_id,
            change=data.change,
            name_machine=data.name_machine,
            address=data.address,
            coordinates=data.coordinates,
            opening_hours=data.opening_hours,
            notes=data.notes,
            time_zone=data.time_zone,
            service_priority=data.service_priority,
            operating_mode=data.operating_mode
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_vending_machines(id, session) -> str:
    '''
    Удаление машины
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(VendingMachines, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_vending_machines(id, data, session) -> VendingMachines:
    '''
    Изменение машины
    :param data:
    :param session:
    :return: VendingMachines
    '''
    try:
        result = session.get(VendingMachines, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_vending_machines(session: Session, page: int = 1, size: int = 10) -> Page[VendingMachines]:
    '''
    Вывод информации о машинах
    :param session:
    :param page
    :param size
    :return: List[VendingMachines]
    '''
    try:
        sql = select(VendingMachines)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")