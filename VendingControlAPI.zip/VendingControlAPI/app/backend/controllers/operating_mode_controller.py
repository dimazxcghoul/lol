from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import OperatingMode


def get_operating_mode_by_id(id, session) -> OperatingMode:
    '''
    Поиск режима работы по ID
    :param id:
    :param session:
    :return: OperatingMode
    '''
    try:
        result = session.get(OperatingMode, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_operating_mode(data, session) -> Optional[OperatingMode]:
    '''
    Добавление режима работы
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = OperatingMode(
            mode=data.mode
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_operating_mode(id, session) -> str:
    '''
    Удаление режима работы
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(OperatingMode, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_operating_mode(id, data, session) -> OperatingMode:
    '''
    Изменение режима работы
    :param data:
    :param session:
    :return: OperatingMode
    '''
    try:
        result = session.get(OperatingMode, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_operating_mode(session: Session, page: int = 1, size: int = 10) -> Page[OperatingMode]:
    '''
    Вывод информации о режимах работы
    :param session:
    :param page
    :param size
    :return: List[OperatingMode]
    '''
    try:
        sql = select(OperatingMode)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")