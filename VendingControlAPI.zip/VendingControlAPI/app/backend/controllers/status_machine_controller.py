from typing import List, Optional
from fastapi import Depends, HTTPException, status
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError
from app.backend.database.session import get_session
from app.backend.models import StatusMachine


def get_status_machine_by_id(id, session) -> StatusMachine:
    '''
    Поиск статуса машины по ID
    :param id:
    :param session:
    :return: StatusMachine
    '''
    try:
        result = session.get(StatusMachine, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def add_status_machine(data, session) -> Optional[StatusMachine]:
    '''
    Добавление статуса машины
    :param data:
    :param session:
    :return: data
    '''
    try:
        obj = StatusMachine(
            status=data.status
        )
        session.add(obj)
        session.commit()
        session.refresh(obj)
        return obj
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=400, detail="Ошибка: нарушение целостности данных")
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Внутренняя ошибка сервера: {str(e)}")


def delete_status_machine(id, session) -> str:
    '''
    Удаление статуса машины
    :param id:
    :param session:
    :return: str
    '''
    try:
        result = session.get(StatusMachine, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        session.delete(result)
        session.commit()
        return "Удаление выполнено"
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def update_status_machine(id, data, session) -> StatusMachine:
    '''
    Изменение статуса машины
    :param data:
    :param session:
    :return: StatusMachine
    '''
    try:
        result = session.get(StatusMachine, id)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"ID не найден")
        for key, value in data.dict(exclude_unset=True).items():
            setattr(result, key, value)
        session.commit()
        session.refresh(result)
        return result
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")


def show_status_machines(session: Session, page: int = 1, size: int = 10) -> Page[StatusMachine]:
    '''
    Вывод информации о статусах машин
    :param session:
    :param page
    :param size
    :return: List[StatusMachine]
    '''
    try:
        sql = select(StatusMachine)
        return paginate(session, sql)
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Внутренняя ошибка сервера: {str(e)}")